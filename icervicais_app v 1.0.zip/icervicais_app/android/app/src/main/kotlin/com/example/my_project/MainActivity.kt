package com.mycompany.icervicaisapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
