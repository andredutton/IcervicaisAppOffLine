// Export pages
export 'login/login_widget.dart' show LoginWidget;
export 'home/home_widget.dart' show HomeWidget;
export 'cadastro_01/cadastro01_widget.dart' show Cadastro01Widget;
export 'cadastro_02/cadastro02_widget.dart' show Cadastro02Widget;
export 'cadastro_03/cadastro03_widget.dart' show Cadastro03Widget;
export 'cadastro_04/cadastro04_widget.dart' show Cadastro04Widget;
export 'cadastro_05/cadastro05_widget.dart' show Cadastro05Widget;
export 'cadastro_06/cadastro06_widget.dart' show Cadastro06Widget;
export 'cadastro_07_foto1/cadastro07_foto1_widget.dart'
    show Cadastro07Foto1Widget;
export 'cadastro_07_foto2/cadastro07_foto2_widget.dart'
    show Cadastro07Foto2Widget;
export 'cadastro_07_foto3/cadastro07_foto3_widget.dart'
    show Cadastro07Foto3Widget;
export 'cadastro_08_fim/cadastro08_fim_widget.dart' show Cadastro08FimWidget;
export 'qrcode/qrcode_widget.dart' show QrcodeWidget;
export 'sincronizar/sincronizar_widget.dart' show SincronizarWidget;
export 'listaparticipantes/listaparticipantes_widget.dart'
    show ListaparticipantesWidget;
